"""Building blocks of the final hybrid recommender.

score(u, i) = z_user(EASE) + alpha * z(Trending) + beta * z_user(MF predicted rating)

* EASE: item-item model on 4-5 star ratings, user profile weighted towards recent ratings (item_models.py).
* Trending: log(1 + ratings in the last `window` days), standardised over the catalogue.
* MF: biased matrix factorization saved by notebook 04; gives a predicted star rating for every movie.
"""
import numpy as np
import pandas as pd
import torch

from item_models import interaction_matrix, dense_rows, gram, fit_ease


def signal_df(df, signal):
    """The ratings used as implicit feedback: all of them, or only 4-5 stars."""
    return df if signal == "all ratings" else df[df["rating"] >= 4]


def fit_ease_stage(df_fit, n_users, n_items, lam, tau, signal, device):
    """EASE weights and the (recency-weighted) user profiles, both from df_fit."""
    sig = signal_df(df_fit, signal)
    W = fit_ease(gram(interaction_matrix(sig, n_users, n_items), device), lam)
    profile = interaction_matrix(sig, n_users, n_items, tau_days=tau, end_date=df_fit["date"].max())
    return W, profile


def trend_counts(df, window_days, n_items):
    recent = df[df["date"] >= df["date"].max() - pd.Timedelta(days=window_days)]
    return np.bincount(recent["item_idx"], minlength=n_items)


def trend_z(df, window_days, n_items, device):
    c = np.log1p(trend_counts(df, window_days, n_items)).astype(np.float32)
    known = np.bincount(df["item_idx"], minlength=n_items) > 0
    return torch.tensor((c - c[known].mean()) / c[known].std(), device=device)


def load_mf(path, device):
    sd = torch.load(path, map_location=device)["state_dict"]
    return {k: v.to(device) for k, v in sd.items()}


def mf_ratings(mf, u):
    """Predicted star rating of every movie for the users in tensor u, shape (len(u), n_items)."""
    return (mf["mu"] + mf["bu.weight"][u] + mf["bi.weight"].squeeze(-1).unsqueeze(0)
            + mf["P.weight"][u] @ mf["Q.weight"].T)


def rowz(x):
    return (x - x.mean(1, keepdim=True)) / (x.std(1, keepdim=True) + 1e-6)


def hybrid_scorer(W, profile, tz, alpha=0.0, mf=None, beta=0.0):
    """score_fn for recsys_eval.Evaluator. A user with an empty profile gets EASE z = 0, i.e. pure Trending."""
    def score(u):
        s = rowz(dense_rows(profile, u.cpu().numpy(), W.device) @ W)
        if alpha:
            s = s + alpha * tz.unsqueeze(0)
        if beta:
            s = s + beta * rowz(mf_ratings(mf, u))
        return s
    return score
