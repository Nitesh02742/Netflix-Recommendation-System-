"""Shared evaluation code: RMSE/MAE for rating prediction and top-K ranking metrics.

Every model is evaluated through this module, so all reported numbers use the same protocol:

* The model is trained on `train_df`. Ranking candidates are every item seen in `train_df`
  that the user has not rated in `train_df`.
* A target item is relevant when its rating is >= threshold (3.5, so 4 and 5 stars).
* Only target rows whose user and item both appear in `train_df` are scored (no cold start).
* Ranking metrics are averaged over users with at least one relevant target item.
"""
import math

import numpy as np
import pandas as pd
import scipy.sparse as sp
import torch


def to_csr(df, n_users, n_items):
    m = sp.csr_matrix(
        (np.ones(len(df), dtype=np.float32), (df["user_idx"].to_numpy(), df["item_idx"].to_numpy())),
        shape=(n_users, n_items),
    )
    m.sum_duplicates()
    m.sort_indices()
    return m


def _gather_rows(indptr, indices, rows):
    """(local_row, col) pairs for all nonzeros in the given CSR rows, without a Python loop."""
    starts, ends = indptr[rows], indptr[rows + 1]
    lens = ends - starts
    local = np.repeat(np.arange(len(rows)), lens)
    offsets = np.arange(lens.sum()) - np.repeat(np.cumsum(lens) - lens, lens)
    cols = indices[np.repeat(starts, lens) + offsets]
    return local, cols


class Evaluator:
    def __init__(self, train_df, target_df, n_users, n_items, threshold=3.5, k=10, device=None):
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.k, self.n_users, self.n_items, self.threshold = k, n_users, n_items, threshold

        known_users = np.zeros(n_users, dtype=bool)
        known_users[train_df["user_idx"].to_numpy()] = True
        known_items = np.zeros(n_items, dtype=bool)
        known_items[train_df["item_idx"].to_numpy()] = True

        keep = known_users[target_df["user_idx"].to_numpy()] & known_items[target_df["item_idx"].to_numpy()]
        self.n_target_dropped = int((~keep).sum())
        self.target = target_df.loc[keep, ["user_idx", "item_idx", "rating"]].reset_index(drop=True)

        seen = to_csr(train_df, n_users, n_items)
        self._seen = (seen.indptr, seen.indices)
        rel = to_csr(self.target[self.target["rating"] >= threshold], n_users, n_items)
        self._rel = (rel.indptr, rel.indices)
        self.users = np.flatnonzero(np.diff(rel.indptr) > 0)          # users we can rank for

        self._unknown_items = torch.as_tensor(~known_items, device=self.device)

        # popularity percentile of each item in the training data (1.0 = most rated)
        counts = np.bincount(train_df["item_idx"].to_numpy(), minlength=n_items)
        self._pop_pct = torch.as_tensor(pd.Series(counts).rank(pct=True).to_numpy().copy(), dtype=torch.float32,
                                        device=self.device)
        self._n_known_items = int(known_items.sum())

    # ---------------------------------------------------------------- rating prediction
    @torch.no_grad()
    def rating_metrics(self, predict_fn, batch_size=2_000_000):
        """predict_fn(user_idx_tensor, item_idx_tensor) -> predicted ratings (any shape-(n,) tensor)."""
        u = torch.as_tensor(self.target["user_idx"].to_numpy().copy(), dtype=torch.long)
        i = torch.as_tensor(self.target["item_idx"].to_numpy().copy(), dtype=torch.long)
        r = torch.as_tensor(self.target["rating"].to_numpy().copy(), dtype=torch.float32)
        sq, ab = 0.0, 0.0
        for s in range(0, len(r), batch_size):
            pred = predict_fn(u[s:s + batch_size].to(self.device), i[s:s + batch_size].to(self.device))
            err = pred.float().clamp(1, 5) - r[s:s + batch_size].to(self.device)
            sq += float((err ** 2).sum())
            ab += float(err.abs().sum())
        n = len(r)
        return {"rmse": math.sqrt(sq / n), "mae": ab / n, "n_ratings": n}

    # ---------------------------------------------------------------- top-K ranking
    @torch.no_grad()
    def ranking_metrics(self, score_fn, batch_size=1024, return_per_user=False):
        """score_fn(user_idx_tensor) -> (n_users_in_batch, n_items) scores; higher = recommend first."""
        k, dev = self.k, self.device
        positions = torch.arange(1, k + 1, device=dev, dtype=torch.float32)
        discounts = 1.0 / torch.log2(positions + 1)
        ideal = torch.cumsum(discounts, 0)

        ap_all, prec_all, rec_all, ndcg_all, hit_all, nrel_all, pop_all = [], [], [], [], [], [], []
        rec_counts = torch.zeros(self.n_items, device=dev)

        for start in range(0, len(self.users), batch_size):
            users = self.users[start:start + batch_size]
            scores = score_fn(torch.as_tensor(users, device=dev)).to(dev, torch.float32).clone()

            rows, cols = _gather_rows(*self._seen, users)
            scores[torch.as_tensor(rows, device=dev), torch.as_tensor(cols, device=dev)] = -math.inf
            scores[:, self._unknown_items] = -math.inf
            top = scores.topk(k, dim=1).indices

            rows, cols = _gather_rows(*self._rel, users)
            relevant = torch.zeros(len(users), self.n_items, dtype=torch.bool, device=dev)
            relevant[torch.as_tensor(rows, device=dev), torch.as_tensor(cols, device=dev)] = True

            hits = relevant.gather(1, top).float()
            n_rel = relevant.sum(1).float()
            n_hits = hits.sum(1)
            precision_at = torch.cumsum(hits, 1) / positions

            ap_all.append((hits * precision_at).sum(1) / n_rel.clamp(max=k))
            prec_all.append(n_hits / k)
            rec_all.append(n_hits / n_rel)
            ndcg_all.append((hits * discounts).sum(1) / ideal[n_rel.clamp(max=k).long() - 1])
            hit_all.append((n_hits > 0).float())
            nrel_all.append(n_rel)
            pop_all.append(self._pop_pct[top].mean(1))
            rec_counts += torch.bincount(top.flatten(), minlength=self.n_items)

        cat = lambda xs: torch.cat(xs).cpu().numpy()
        ap = cat(ap_all)
        out = {
            f"map@{k}": float(ap.mean()),
            f"precision@{k}": float(cat(prec_all).mean()),
            f"recall@{k}": float(cat(rec_all).mean()),
            f"ndcg@{k}": float(cat(ndcg_all).mean()),
            f"hit_rate@{k}": float(cat(hit_all).mean()),
            "coverage": float((rec_counts > 0).sum().item() / self._n_known_items),
            "mean_pop_percentile": float(cat(pop_all).mean()),
            "n_users": int(len(self.users)),
        }
        if return_per_user:
            per_user = pd.DataFrame({"user_idx": self.users, "ap": ap, "n_relevant": cat(nrel_all)})
            return out, per_user
        return out

    def evaluate(self, predict_fn=None, score_fn=None, **kw):
        result = {}
        if predict_fn is not None:
            result.update(self.rating_metrics(predict_fn))
        if score_fn is not None:
            result.update(self.ranking_metrics(score_fn, **kw))
        return result
