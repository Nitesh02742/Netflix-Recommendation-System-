"""Item-to-item recommenders trained on implicit feedback ("the user rated this movie").

Both models learn an item x item weight matrix W from the user x item interaction matrix X, and score a user as
profile @ W, where profile is the user's row of X (optionally weighted towards recent ratings).

* Item-KNN: W = cosine similarity between item columns of X, keeping each item's top neighbours.
* EASE (Steck, 2019): W = argmin ||X - X W||^2 + lam ||W||^2 subject to diag(W) = 0, which has the closed form
  P = (X^T X + lam I)^-1,  W = -P / diag(P),  diag(W) = 0.
"""
import numpy as np
import scipy.sparse as sp
import torch


def interaction_matrix(df, n_users, n_items, tau_days=None, end_date=None):
    """Sparse user x item matrix. Values are 1, or exp(-age / tau) with age in days before end_date."""
    if tau_days is None:
        w = np.ones(len(df), dtype=np.float32)
    else:
        end = df["date"].max() if end_date is None else end_date
        age = (end - df["date"]).dt.days.to_numpy()
        w = np.exp(-age / tau_days).astype(np.float32)
    m = sp.csr_matrix((w, (df["user_idx"].to_numpy(), df["item_idx"].to_numpy())), shape=(n_users, n_items))
    m.sum_duplicates()
    m.sort_indices()
    return m


def dense_rows(m, users, device):
    """Rows `users` (numpy int array) of CSR matrix m as a dense float32 tensor on device."""
    starts, ends = m.indptr[users], m.indptr[users + 1]
    lens = ends - starts
    local = np.repeat(np.arange(len(users)), lens)
    idx = np.repeat(starts, lens) + (np.arange(lens.sum()) - np.repeat(np.cumsum(lens) - lens, lens))
    out = torch.zeros(len(users), m.shape[1], device=device)
    out[torch.as_tensor(local, device=device), torch.as_tensor(m.indices[idx].astype(np.int64), device=device)] = \
        torch.as_tensor(m.data[idx], device=device)
    return out


@torch.no_grad()
def gram(m, device, chunk=8192):
    """X^T X as a dense (n_items, n_items) float32 tensor, built on the GPU in user chunks."""
    n_items = m.shape[1]
    g = torch.zeros(n_items, n_items, device=device)
    for s in range(0, m.shape[0], chunk):
        block = dense_rows(m, np.arange(s, min(s + chunk, m.shape[0])), device)
        g += block.T @ block
    return g


@torch.no_grad()
def fit_ease(g, lam):
    """EASE weights from the Gram matrix. The inverse is done in float64 for numerical safety."""
    p = g.double()
    p.diagonal().add_(lam)
    p = torch.linalg.inv(p)
    w = -p / p.diagonal().unsqueeze(0)
    w.diagonal().zero_()
    return w.float()


@torch.no_grad()
def fit_itemknn(g, n_neighbors=None, shrink=0.0):
    """Cosine item-item similarity from the Gram matrix, keeping each item's n_neighbors most similar items."""
    norms = g.diagonal().sqrt()
    s = g / (norms.unsqueeze(0) * norms.unsqueeze(1) + shrink + 1e-8)
    s.diagonal().zero_()
    if n_neighbors is not None and n_neighbors < s.shape[0]:
        top = s.topk(n_neighbors, dim=0)
        s = torch.zeros_like(s).scatter_(0, top.indices, top.values)
    return s


def scorer(profile, w, device):
    """score_fn for recsys_eval.Evaluator: profile rows @ W."""
    return lambda u: dense_rows(profile, u.cpu().numpy(), device) @ w
