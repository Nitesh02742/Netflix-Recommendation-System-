# Netflix Prize recommender

A movie recommender built on the [Netflix Prize dataset](https://www.kaggle.com/datasets/netflix-inc/netflix-prize-data) (100,480,507 ratings from 480,189 users on 17,770 movies) for the problem statement *Recommendation Systems for Personalized Content Discovery* (Open Projects 2026).

The final model is a hybrid ranker. For every user it adds three standardised scores: EASE, an item-to-item model of what viewers with similar histories went on to rate highly; the number of ratings each movie received in the last 7 days; and the star rating predicted by matrix factorization (SVD). On a time-based test set it reaches **MAP@10 0.078**, 70% above the strongest baseline, and the matrix factorization component reaches **RMSE 0.901**.

The full write-up, with all tables, charts and example recommendations, is in [`report/Netflix_Recommender_Project_Summary.pdf`](report/Netflix_Recommender_Project_Summary.pdf).

## Results

Test set: the last 10% of ratings by date (6 October to 31 December 2005). A movie counts as relevant if the user rated it 4 or 5 stars. Every model ranks all ~12,000 movies for each of the 44,358 test users; nothing is sampled.

| Model | RMSE | MAP@10 | NDCG@10 | Hit rate@10 | Coverage |
|---|---|---|---|---|---|
| Global mean | 1.073 | | | | |
| User + movie bias | 0.949 | 0.014 | 0.030 | 0.151 | 0.5% |
| Most popular | | 0.020 | 0.042 | 0.197 | 2.6% |
| Trending (last 14 days) | | 0.046 | 0.091 | 0.395 | 1.5% |
| Matrix factorization (SVD) | 0.901 | 0.019 | 0.041 | 0.197 | 38.8% |
| Item-KNN + recency | | 0.052 | 0.096 | 0.363 | 59.5% |
| EASE + recency | | 0.063 | 0.119 | 0.444 | 36.7% |
| **Hybrid (EASE + Trending + MF)** | **0.901** | **0.078** | **0.141** | **0.485** | 7.9% |

Coverage is the share of the catalogue that appears in at least one user's top 10. The hybrid uses matrix factorization for rating prediction, so its RMSE is the same. All metrics are in [`results/test_metrics.csv`](results/test_metrics.csv).

![Test MAP@10 of every model](figures/model_comparison_map.png)

What moved MAP@10:

| Step | MAP@10 | Set |
|---|---|---|
| EASE trained on every rating | 0.033 | validation |
| EASE trained on 4-5 star ratings only | 0.051 | validation |
| + recency weighting of the user profile (τ = 90 days) | 0.067 | validation |
| + trending and MF predicted rating (hybrid) | 0.087 | validation |
| EASE + recency | 0.063 | test |
| Hybrid | 0.078 | test |

Matrix factorization predicts ratings best but ranks poorly on its own, because it favours niche titles (TV box sets, bonus discs) that only their fans rate. Inside the hybrid it is the most useful extra signal: it separates movies a user will watch and like from movies they would only watch.

**New users.** EASE needs no retraining for someone who has just joined, only their first ratings. For the 4,630 users who joined during the test period, MAP@10 is 0.057 with no ratings (the trending fallback), 0.106 after one rating and 0.252 after ten ([`results/cold_start.csv`](results/cold_start.csv)).

![Cold start](figures/cold_start.png)

**Explanations.** Each recommendation can be explained by the liked movies that contributed most to its EASE score, its trending rank and its predicted rating, for example *The Usual Suspects: because you liked Glengarry Glen Ross and Reservoir Dogs, predicted 5.0★* (the user rated it 5★ in the test period). Notebook 07 shows these for real users, including two success and two failure cases.

## How it works

1. **Data.** The four raw files are parsed in chunks and checked against the published counts. Modelling uses a subset: 20% of users with at least 20 ratings (seed 42), with their full histories, after removing movies with fewer than 50 ratings. That leaves 19,812,180 ratings from 85,775 users on 12,190 movies.
2. **Split.** One global time cut-off: train is the oldest 80% (to 6 August 2005), validation the next 10%, test the newest 10%. Settings are chosen on validation; each model is then refit on train + validation and scored once on test. Ratings from users or movies absent from the fitting data (cold start) are left out of the main evaluation and studied separately.
3. **Evaluation.** One shared module, [`src/recsys_eval.py`](src/recsys_eval.py), scores every model on the GPU: RMSE and MAE for rating prediction; MAP@10, NDCG@10, recall, precision, hit rate, coverage and popularity for top-10 lists. AP@10 divides by min(number of relevant movies, 10) and MAP@10 averages over all users with at least one relevant test movie.
4. **Models.** Baselines (global mean, user + movie bias, most popular, trending), biased matrix factorization in PyTorch with early stopping, Item-KNN and EASE ([`src/item_models.py`](src/item_models.py)), and the hybrid ([`src/hybrid.py`](src/hybrid.py)). The hybrid's settings are in [`results/hybrid_config.json`](results/hybrid_config.json).

## Repository layout

```
notebooks/   01-07, run in order on Kaggle
src/         evaluation, item models (Item-KNN, EASE) and the hybrid
results/     test metrics, cold-start results, results by user segment, final settings
figures/     charts used in the report
report/      project summary (PDF)
```

| Notebook | What it does |
|---|---|
| 01_data_preparation | parses and checks the raw data, builds the subset |
| 02_eda | exploratory analysis and charts |
| 03_split_eval_baselines | time split, evaluation module, baselines |
| 04_matrix_factorization | biased matrix factorization (SVD) with a hyperparameter search |
| 05_item_models | Item-KNN and EASE, rating signal, recency weighting |
| 06_hybrid_cold_start | hybrid tuning, ablation, cold-start experiment |
| 07_analysis | results by user segment, success and failure cases, explanations |

## Reproducing

The notebooks are written for Kaggle with a T4 GPU, and each one reads the previous notebooks' saved output.

1. Create notebook 01 on Kaggle, add the Netflix Prize dataset as input, and run it with **Save Version → Save & Run All**.
2. For each later notebook, add the earlier notebooks' saved versions as input (**Add Input → Your Work**), set the accelerator to GPU T4, and run **Save & Run All**. Notebook 03 needs 01; 04 and 05 need 03; 06 needs 03, 04 and 05; 07 needs 01 to 06.
3. Files are found with `glob("/kaggle/input/**/<name>")`, so input folder names do not matter.

Running everything takes roughly an hour of GPU time. Outside Kaggle, install `requirements.txt` and change the input and output paths at the top of each notebook.

## Limitations

- The hybrid's top-10 lists cover 7.9% of the catalogue against 36.7% for EASE alone; the trending term trades variety for accuracy.
- Users whose new favourites are niche titles gain nothing from the hybrid (MAP@10 0.035, the same as EASE).
- Plain matrix factorization stops at RMSE 0.901; time-aware biases (timeSVD++) would address the upward drift in ratings over time.
- Models were tuned on a 20% sample of users with one random seed.
